﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PokerLibrary;

namespace PokerUnitTestProject
{
    [TestClass]
    public class PokerUnitTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            string msg = "";

            var game1 = new Game();
            bool isAdded = game1.AddPlayerToGame("Person A", "1", "ace", ref msg);
            isAdded = game1.AddPlayerToGame("Person A", "4", "king", ref msg);
            isAdded = game1.AddPlayerToGame("Person A", "1", "jack", ref msg);
            isAdded = game1.AddPlayerToGame("Person A", "2", "jack", ref msg);
            isAdded = game1.AddPlayerToGame("Person A", "3", "jack", ref msg);

            // We have given 5 card to player A and now need to check numbers of cards in hands
            // Result: passed ( it give numbers of card in hands of Person A ==> 5
            Assert.AreEqual(5, game1.GetCardByPlayerName("Person A"));

            // We cant give 6 card to player
            // Result: passed ( it mainatin restriction of 5 card only
            isAdded = game1.AddPlayerToGame("Person A", "4", "jack", ref msg);
            Assert.AreEqual(5, game1.GetCardByPlayerName("Person A"));

            isAdded = game1.AddPlayerToGame("Person B", "2", "ace", ref msg);
            isAdded = game1.AddPlayerToGame("Person B", "2", "king", ref msg);
            isAdded = game1.AddPlayerToGame("Person B", "2", "jack", ref msg);
            isAdded = game1.AddPlayerToGame("Person B", "2", "queen", ref msg);
            isAdded = game1.AddPlayerToGame("Person B", "2", "two", ref msg);
            Assert.AreEqual(5, game1.GetCardByPlayerName("Person B"));


            isAdded = game1.AddPlayerToGame("Person C", "3", "ace", ref msg);
            isAdded = game1.AddPlayerToGame("Person C", "3", "king", ref msg);
            isAdded = game1.AddPlayerToGame("Person C", "3", "jack", ref msg);
            isAdded = game1.AddPlayerToGame("Person C", "3", "queen", ref msg);
            isAdded = game1.AddPlayerToGame("Person C", "3", "five", ref msg);
            Assert.AreEqual(5, game1.GetCardByPlayerName("Person C"));

            isAdded = game1.AddPlayerToGame("Person D", "1", "ace", ref msg);
            isAdded = game1.AddPlayerToGame("Person D", "2", "king", ref msg);
            isAdded = game1.AddPlayerToGame("Person D", "3", "jack", ref msg);
            isAdded = game1.AddPlayerToGame("Person D", "2", "seven", ref msg);
            isAdded = game1.AddPlayerToGame("Person D", "3", "seven", ref msg);
            Assert.AreEqual(5, game1.GetCardByPlayerName("Person D"));


            bool isWinnerSelected = game1.checkHands(ref msg);
            isWinnerSelected = game1.findWinnigHands(ref msg);
            Assert.AreEqual("Person C", game1.GetFirstWinnerPlayerName());

        }
    }
}
