﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerLibrary
{
    public class PlayerDetails
    {
        protected internal string PlayerName { get; set; }
        protected internal List<CardDetail> cardInHands = new List<CardDetail>();
        protected internal _typeOfHands typeOfHands { get; set; }
        protected internal int totalRankvalue { get; set; }

        protected internal int WinningRank { get; set; }

    }

    public enum _typeOfHands
    {
        flush = 1,
        threeKind = 2,
        onePair = 3,
        highCard = 4,
    }
}




