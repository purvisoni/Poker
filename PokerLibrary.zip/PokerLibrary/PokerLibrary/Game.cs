﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerLibrary
{
    public class Game
    {
        private List<PlayerDetails> listOfPlayersInGame = new List<PlayerDetails>();

        /// <summary>
        ///  Add player by Name and Card Type and Card Rank
        /// </summary>
        /// <param name="playername"></param>
        /// <param name="cardType"></param>
        /// <param name="cardRank"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool AddPlayerToGame(string playername, string cardType, string cardRank, ref string msg)
        {
            bool isAdded = false;
            cardTypeEnum crdType = (cardTypeEnum)Enum.Parse(typeof(cardTypeEnum), cardType, true);
            cardRankEnum crdRank = (cardRankEnum)Enum.Parse(typeof(cardRankEnum), cardRank, true);
            CardDetail objCardDetail = new CardDetail();
            PlayerDetails objPlayerDetails;

            if ((this.listOfPlayersInGame.Count() < 1) || (this.listOfPlayersInGame.Count() > 0 && this.listOfPlayersInGame.Count(s => s.PlayerName.ToLower() == playername.ToLower()) == 0))
            {
                objCardDetail.cardType = (int)crdType;
                objCardDetail.cardRank = (int)crdRank;//Convert.ToInt32(crdRank.GetType().ToString());

                objPlayerDetails = new PlayerDetails();
                objPlayerDetails.PlayerName = playername;
                objPlayerDetails.cardInHands.Add(objCardDetail);
                listOfPlayersInGame.Add(objPlayerDetails);
                msg = "Card Added for : '" + playername + "' Total Card(s) to this  player is : (" + objPlayerDetails.cardInHands.Count.ToString() + ").  Card : " + crdType + "{" + crdRank + "}";
                isAdded = true;

            }
            else if (this.listOfPlayersInGame.Count() > 0 && this.listOfPlayersInGame.Count(s => s.PlayerName.ToLower() == playername.ToLower()) >= 1)
            {
                objPlayerDetails = listOfPlayersInGame.Where(s => s.PlayerName.ToLower() == playername.ToLower()).FirstOrDefault();
                if (objPlayerDetails != null)
                {
                    if (objPlayerDetails.cardInHands.Count < 5)
                    {
                        objCardDetail.cardType = (int)crdType;
                        objCardDetail.cardRank = (int)crdRank;//Convert.ToInt32(crdRank.GetType().ToString());
                        objPlayerDetails.cardInHands.Add(objCardDetail);
                        //listOfPlayersInGame.Add(objPlayerDetails);
                        isAdded = true;
                        //msg = "Card Added for : '" + playername + "' Total Card(s) to this  player is : (" + objPlayerDetails.cardInHands.Count.ToString() + ")";
                        msg = "Card Added for : '" + playername + "' Total Card(s) to this  player is : (" + objPlayerDetails.cardInHands.Count.ToString() + ").  Card : " + crdType + "{" + crdRank + "}";
                    }
                    else
                    {
                        msg = "Can not add more than 5 cards";
                        isAdded = false;
                    }
                }
            }

            return isAdded;
        }

        /// <summary>
        /// find the winners based on hand type and rank value in case of tie
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool findWinnigHands(ref string msg)
        {
            msg = "@";
            bool ischecked = false;
            int position = 1;
            List<PlayerDetails> lstPlayerList = this.listOfPlayersInGame.ToList();

            var results = lstPlayerList.GroupBy(
                  p => p.typeOfHands,
                  p => p.totalRankvalue,
                  (key, g) => new { selecttypeOfHands = key, selecttotalRankvalue = g.ToList(), cnt = g.ToList().Count() });

            if (results.Where(s => s.selecttypeOfHands == _typeOfHands.flush).Count() > 0) // give Winning Rank to flush hands
            {
                lstPlayerList = this.listOfPlayersInGame.ToList().Where(s => s.typeOfHands == _typeOfHands.flush).OrderByDescending(s => s.totalRankvalue).ToList();
                foreach (PlayerDetails objPlayerDetails in lstPlayerList)
                {
                    this.listOfPlayersInGame.Where(s => s.PlayerName == objPlayerDetails.PlayerName).FirstOrDefault().WinningRank = position;
                    position += 1;
                }
            }

            if (results.Where(s => s.selecttypeOfHands == _typeOfHands.threeKind).Count() > 0) // give Winning Rank to threeKind hands
            {
                lstPlayerList = this.listOfPlayersInGame.ToList().Where(s => s.typeOfHands == _typeOfHands.threeKind).OrderByDescending(s => s.totalRankvalue).ToList();
                foreach (PlayerDetails objPlayerDetails in lstPlayerList)
                {
                    this.listOfPlayersInGame.Where(s => s.PlayerName == objPlayerDetails.PlayerName).FirstOrDefault().WinningRank = position;
                    position += 1;
                }
            }

            if (results.Where(s => s.selecttypeOfHands == _typeOfHands.onePair).Count() > 0) // give Winning Rank to onePair hands
            {
                lstPlayerList = this.listOfPlayersInGame.ToList().Where(s => s.typeOfHands == _typeOfHands.onePair).OrderByDescending(s => s.totalRankvalue).ToList();
                foreach (PlayerDetails objPlayerDetails in lstPlayerList)
                {
                    this.listOfPlayersInGame.Where(s => s.PlayerName == objPlayerDetails.PlayerName).FirstOrDefault().WinningRank = position;
                    position += 1;
                }
            }


            if (results.Where(s => s.selecttypeOfHands == _typeOfHands.highCard).Count() > 0) // give Winning Rank to highCard hands
            {
                lstPlayerList = this.listOfPlayersInGame.ToList().Where(s => s.typeOfHands == _typeOfHands.highCard).OrderByDescending(s => s.totalRankvalue).ToList();
                foreach (PlayerDetails objPlayerDetails in lstPlayerList)
                {
                    this.listOfPlayersInGame.Where(s => s.PlayerName == objPlayerDetails.PlayerName).FirstOrDefault().WinningRank = position;
                    position += 1;
                }
            }

            msg = "@ ";

            foreach (PlayerDetails objPlayerDetails in this.listOfPlayersInGame.OrderBy(s => s.WinningRank).ToList())
            {
                msg += "@  Player Name: '" + objPlayerDetails.PlayerName + "' ==>> Winning Rank: " + objPlayerDetails.WinningRank;
            }

            return ischecked;
        }

        /// <summary>
        /// 
        ///  initally handtype 
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool checkHands(ref string msg)
        {
            bool ischecked = false;
            PlayerDetails objPlayerDetails;
            int uniqueCardType = 0;
            int uniqueCardRank = 0;
            int threeSameCard = 3;
            int twoSameCard = 2;
            msg = "@";
            for (int i = 0; i < this.listOfPlayersInGame.Count(); i++)
            {
                objPlayerDetails = this.listOfPlayersInGame[i];
                List<CardDetail> lstCardDetail = objPlayerDetails.cardInHands.ToList();

                // set the typeofhands
                if (objPlayerDetails.cardInHands.Count == 5)
                {
                    uniqueCardType = lstCardDetail.GroupBy(s => s.cardType).Count();
                    uniqueCardRank = lstCardDetail.GroupBy(s => s.cardRank).Count();

                    List<int> lstuniqueCardType = lstCardDetail.GroupBy(s => s.cardType).ToList().Select(s => s.Key).ToList();
                    List<int> lstuniqueCardRank = lstCardDetail.GroupBy(s => s.cardRank).ToList().Select(s => s.Key).ToList();


                    var results = lstCardDetail.GroupBy(
                    p => p.cardRank,
                    p => p.cardType,
                    (key, g) => new { selectRank = key, selectCardType = g.ToList(), cnt = g.ToList().Count() });

                    objPlayerDetails.totalRankvalue = objPlayerDetails.cardInHands.Sum(s => s.cardRank); // based on rank top perosn will be winner 
                    if (uniqueCardType == 1) // chck for flush // have same type Black or heart or diamond or spread
                    {

                        objPlayerDetails.typeOfHands = _typeOfHands.flush;
                        ischecked = true;
                        msg += this.listOfPlayersInGame[i].PlayerName + " has hand type : " + _typeOfHands.flush.ToString() + "@";
                    }

                    if (uniqueCardRank == 3) // Ex:  jack jack jack king and queen - total distinct rank = 3
                    {
                        if (results.ToList().Where(s => s.cnt == threeSameCard).Count() == 1) // three card same 
                        {

                            objPlayerDetails.typeOfHands = _typeOfHands.threeKind;
                            ischecked = true;
                            msg += this.listOfPlayersInGame[i].PlayerName + " has hand type : " + _typeOfHands.threeKind.ToString() + "@";
                        }
                    }

                    if (uniqueCardType > 1 && uniqueCardRank >= 3 && (results.ToList().Where(s => s.cnt == twoSameCard).Count() > 0)) // checking for pair in the hand if count >0  then one pair 
                    {
                        objPlayerDetails.typeOfHands = _typeOfHands.onePair;
                        ischecked = true;
                        msg += this.listOfPlayersInGame[i].PlayerName + " has hand type : " + _typeOfHands.onePair.ToString() + "@";
                    }

                    if (ischecked == false)
                    {
                        objPlayerDetails.typeOfHands = _typeOfHands.highCard;
                        ischecked = true;
                        msg += this.listOfPlayersInGame[i].PlayerName + " has hand type : " + _typeOfHands.onePair.ToString() + "@";
                    }

                }
            }

            return ischecked;
        }

        public int GetCardByPlayerName(string playername)
        {
            int countCards = 0;

            if (this.listOfPlayersInGame.Count() > 0 && this.listOfPlayersInGame.Count(s => s.PlayerName.ToLower() == playername.ToLower()) == 1)
            {
                countCards = this.listOfPlayersInGame.Where(s => s.PlayerName.ToLower() == playername.ToLower()).FirstOrDefault().cardInHands.Count;
            }
            return countCards;
        }

        public string GetFirstWinnerPlayerName()
        {
            string WiinnernamePlayer = string.Empty;

            if (this.listOfPlayersInGame.Count() > 0 )
            {
                WiinnernamePlayer = this.listOfPlayersInGame.OrderBy(s => s.WinningRank).ToList().FirstOrDefault().PlayerName;
            }
            return WiinnernamePlayer;
        }
    }
}
