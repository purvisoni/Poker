﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerLibrary
{
    public class CardDetail
    {
        protected internal int cardType;
        protected internal int cardRank;
    }


    // enum for Card Type
    public  enum cardTypeEnum 
    {
        clubs = 1,
        diamonds =2,
        hearts = 3,
        spades = 4
    }

    // enum for Card Rank
    public enum cardRankEnum
    {
        
        two = 1,
        three = 2,
        four = 3,
        five = 4,
        six = 5,
        seven = 6,
        eight = 7,
        nine = 8,
        ten = 9,
        jack = 10,
        queen = 11,
        king = 12,
        ace = 13
    }
}
